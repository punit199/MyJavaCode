package arrry;

public enum Colour 
{
    RED, GREEN, BLUE; 
	
	public static void main(String[] args) 
    { 
        Colour c1 = Colour.RED; 
        System.out.println(c1); 
        System.out.println(RED.ordinal());
    } 

}
