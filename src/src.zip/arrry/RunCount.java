package arrry;

public class RunCount {
	public static void main(String[] args) {
		MethodForCount m = new MethodForCount("jmaba");

	}

}
