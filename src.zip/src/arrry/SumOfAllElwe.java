package arrry;

public class SumOfAllElwe {

	public static void main(String[] args) {
		int sum =0;
		int [] a = {10,2};
		for(int i:a)
		{
			sum = sum+i;
		}
		System.out.println(sum);

	}

}
