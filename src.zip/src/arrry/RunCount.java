package arrry;

import string.MethodForCount;

public class RunCount {
	public static void main(String[] args) {
		MethodForCount m = new MethodForCount("jmaba");

	}

}
