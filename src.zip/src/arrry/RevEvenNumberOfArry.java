package arrry;

public class RevEvenNumberOfArry {
	
	public static void main(String [] arys)
	{
		StringBuffer s = new StringBuffer("punit");
		String re = s.toString();
	    StringBuffer r=s.reverse();
	    System.out.println(r.toString().equals(re));
	}

}
