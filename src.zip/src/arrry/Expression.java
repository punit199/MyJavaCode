package arrry;

public class Expression {

	public static void main(String[] args) {
		System.out.println("a"+(char)178+'+'+"b"+(char)179);

	}

}
